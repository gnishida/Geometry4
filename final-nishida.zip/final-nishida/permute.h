#ifndef PERMUTE
#define PERMUTE

#include <math.h>
#include <algorithm>

void randomPermutation (int n, int *p);

int randomInteger (int lb, int ub);

#endif
